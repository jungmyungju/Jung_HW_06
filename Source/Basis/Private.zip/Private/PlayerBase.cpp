#include "PlayerBase.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "EnhancedInputComponent.h"
#include "Weapon.h"

APlayerBase::APlayerBase()
{
    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(RootComponent);

    FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    FollowCamera->SetupAttachment(CameraBoom);
}

void APlayerBase::BeginPlay()
{
    Super::BeginPlay();

    WeaponActor = GetWorld()->SpawnActor<AWeapon>(Weapon);
    if (Weapon)
    {
        FAttachmentTransformRules TransformRules(EAttachmentRule::SnapToTarget, true);
        WeaponActor->AttachToComponent(GetMesh(), TransformRules, TEXT("WeaponSocket"));
        WeaponActor->SetOwner(this);
        WeaponActor->SetInstigator(this);
    }
}

void APlayerBase::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    if (UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(PlayerInputComponent))
    {
        EnhancedInputComponent->BindAction(MoveAction, ETriggerEvent::Triggered, this, &APlayerBase::Move);
        EnhancedInputComponent->BindAction(LookAction, ETriggerEvent::Triggered, this, &APlayerBase::Look);
        EnhancedInputComponent->BindAction(FireAction, ETriggerEvent::Triggered, this, &APlayerBase::Fire);
        EnhancedInputComponent->BindAction(ZoomAction, ETriggerEvent::Triggered, this, &APlayerBase::Zoom);
    }
}

void APlayerBase::Hit(int32 Damage, AActor* ByWho)
{
    Super::Hit(Damage, ByWho);
    if (CurrentHP > 0)
    {
        return;
    }
    Destroy();
}

void APlayerBase::IncreaseKillCount()
{
    Super::IncreaseKillCount();
}

void APlayerBase::Attack()
{
    Super::Attack();
    if (IsValid(WeaponActor))
    {
        WeaponActor->Fire();
    }
}

void APlayerBase::Move(const FInputActionValue& Value)
{
    FVector2D MovementVector = Value.Get<FVector2D>();

    if (Controller != nullptr)
    {
        AddMovementInput(GetActorForwardVector(), MovementVector.Y);
        AddMovementInput(GetActorRightVector(), MovementVector.X);
    }
}

void APlayerBase::Look(const FInputActionValue& Value)
{
    FVector2D LookAxisVector = Value.Get<FVector2D>();

    if (Controller != nullptr)
    {
        AddControllerYawInput(LookAxisVector.X);
        AddControllerPitchInput(LookAxisVector.Y);
    }
}

void APlayerBase::Fire(const FInputActionValue& Value)
{
    Attack();
}

void APlayerBase::Zoom(const FInputActionValue& Value)
{
    if (!IsValid(CameraBoom))
    {
        return;
    }

    if (Value.Get<bool>())
    {
        CameraBoom->TargetArmLength = 40;
        CameraBoom->SocketOffset = FVector(0, 40, 60);
    }
    else
    {
        CameraBoom->TargetArmLength = 120;
        CameraBoom->SocketOffset = FVector(0, 60, 60);
    }
}

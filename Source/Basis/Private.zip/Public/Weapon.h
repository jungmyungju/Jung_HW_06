#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Weapon.generated.h"


class USceneComponent;

UCLASS()
class BASIS_API AWeapon : public AActor
{
    GENERATED_BODY()
public:
    AWeapon();

protected:
    virtual void BeginPlay() override;

public:
    void Fire();

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<class USkeletalMeshComponent> Mesh;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<class USceneComponent> MuzzleOffset;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<class UAnimMontage> FireMontage;

  
    UPROPERTY(EditAnywhere) 
        TSubclassOf<class ABullet> Bullet;
};
